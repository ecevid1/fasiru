
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
import requests
import os

DUFFEL_API_KEY = os.getenv("DUFFEL_API_KEY", "your-duffel-key")

app = FastAPI()

# Allow frontend from any origin (WordPress site)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

headers = {
    "Authorization": f"Bearer {DUFFEL_API_KEY}",
    "Duffel-Version": "v1",
    "Content-Type": "application/json"
}

@app.get("/")
def root():
    return {"status": "Duffel backend is running."}

@app.post("/search")
async def search_flights(request: Request):
    data = await request.json()
    response = requests.post(
        "https://api.duffel.com/air/offer_requests",
        json={
            "slices": [{
                "origin": data["origin"],
                "destination": data["destination"],
                "departure_date": data["departure_date"]
            }],
            "passengers": [{"type": "adult"} for _ in range(data["passengers"])]
        },
        headers=headers
    )
    return response.json()

@app.get("/offers/{offer_id}")
def get_offer_details(offer_id: str):
    response = requests.get(f"https://api.duffel.com/air/offers/{offer_id}", headers=headers)
    return response.json()

@app.post("/book")
async def book_flight(request: Request):
    data = await request.json()
    response = requests.post(
        "https://api.duffel.com/air/orders",
        json={
            "selected_offers": [data["offer_id"]],
            "payments": [{
                "type": "balance",
                "amount": data["amount"],
                "currency": data["currency"]
            }],
            "passengers": data["passengers"]
        },
        headers=headers
    )
    return response.json()
